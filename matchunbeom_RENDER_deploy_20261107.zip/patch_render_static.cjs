/** Safe static asset support for Backrooms on Render */
const fs = require('node:fs');
const filename = 'server.js';
let src = fs.readFileSync(filename,'utf8');
const guard = 'const safe =';
if (!src.includes(guard) || !src.includes('function publicFile(')) {
  throw new Error('Render server.js changed: refusing unsafe automatic patch');
}
const allow = "    new RegExp('^/backrooms/(?:assets/(?:jumpscare/[A-Za-z0-9_.-]+[.]gif|sfx/[A-Za-z0-9_.-]+[.](?:mp3|wav|ogg)|monsters/[A-Za-z0-9_.-]+[.]glb)|src/[A-Za-z0-9_.-]+[.]mjs)$','i').test(urlPath) ||\n";
if (!src.includes('Backrooms static resources')) {
  src=src.replace('const safe =', () => 'const safe =\n    // Backrooms static resources (visuals, sound, model, runtime modules)\n'+allow);
}
if (src.includes("['.mp3', 'audio/mpeg'],") && !src.includes("['.glb', 'model/gltf-binary'],")) {
  src=src.replace("['.mp3', 'audio/mpeg'],", "['.glb', 'model/gltf-binary'],\n  ['.mjs', 'text/javascript; charset=utf-8'],\n  ['.mp3', 'audio/mpeg'],");
}
fs.writeFileSync(filename,src);
console.log('Render static-file route patched.');
