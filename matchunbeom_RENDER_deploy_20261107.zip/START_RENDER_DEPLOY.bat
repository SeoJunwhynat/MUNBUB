@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0deploy_render.ps1"
pause
