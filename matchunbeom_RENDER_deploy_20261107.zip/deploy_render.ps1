$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
$kit = Split-Path -Parent $MyInvocation.MyCommand.Path
$source = Join-Path $kit 'payload'
$target = Join-Path $kit 'render-git-checkout'
$repo = 'https://github.com/SeoJunwhynat/MUNBUB.git'
$branch = 'migration/render-neon'
Write-Host '==> Deploying to existing Render Git branch:' $branch
if (-not (Get-Command git -ErrorAction SilentlyContinue)) { throw 'Git for Windows required: https://git-scm.com/downloads/win' }
if (-not (Get-Command node -ErrorAction SilentlyContinue)) { throw 'Node.js required: https://nodejs.org/' }
if (Test-Path $target) { throw 'Existing checkout folder detected. Please move render-git-checkout aside, then retry.' }
& git clone --branch $branch --single-branch $repo $target
if ($LASTEXITCODE -ne 0) {throw 'Git clone failed; check your Github login'}
Copy-Item (Join-Path $source 'backrooms\*') (Join-Path $target 'backrooms') -Recurse -Force
Copy-Item (Join-Path $source 'tests\backrooms-*.test.mjs') (Join-Path $target 'tests') -Force
Copy-Item (Join-Path $kit 'patch_render_static.cjs') (Join-Path $target 'patch_render_static.cjs') -Force
Push-Location $target
try {
  & node patch_render_static.cjs
  if ($LASTEXITCODE -ne 0) {throw 'server.js patch failed'}
  Remove-Item 'patch_render_static.cjs'
  & node --check server.js
  if ($LASTEXITCODE -ne 0) {throw 'server syntax failed'}
  & npm install --ignore-scripts --no-audit --no-fund
  if ($LASTEXITCODE -ne 0) {throw 'npm install failed'}
  & npm run check
  if ($LASTEXITCODE -ne 0) {throw 'npm run check failed'}
  & npm test
  if ($LASTEXITCODE -ne 0) {throw 'npm test failed'}
  & git add -- server.js backrooms tests
  & git diff --cached --quiet
  if ($LASTEXITCODE -eq 0) { Write-Host 'No changes to deploy'; exit 0 }
  & git commit -m 'Backrooms: animated GIF jumpscare and new monster/sounds'
  if ($LASTEXITCODE -ne 0) {throw 'git commit failed'}
  & git push origin $branch
  if ($LASTEXITCODE -ne 0) {throw 'git push failed, Render has not received changes'}
  Write-Host 'Push finished. Render auto-deploys this branch.'
  Write-Host 'https://dashboard.render.com/web/srv-dbmhnagm7kps73fec290'
} finally { Pop-Location }
