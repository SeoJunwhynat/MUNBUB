@echo off
setlocal
chcp 65001 >nul
set "HERE=%~dp0"
set "TARGET=%HERE%..\..\MUNBUB_latest_backrooms_deploy"
where git >nul 2>&1 || (echo Git for Windows is required.&exit /b 1)
where py >nul 2>&1 || (echo Python 3 is required.&exit /b 1)
where npm >nul 2>&1 || (echo Node.js and npm are required.&exit /b 1)
if exist "%TARGET%" (echo Target directory already exists: %TARGET%&exit /b 1)
git clone --depth 1 --branch migration/render-neon https://github.com/SeoJunwhynat/MUNBUB.git "%TARGET%" || exit /b 1
py -3 "%HERE%apply_to_latest.py" "%TARGET%" || exit /b 1
cd /d "%TARGET%" || exit /b 1
call npm ci --ignore-scripts --no-audit --no-fund || exit /b 1
call npm run check || exit /b 1
call npm test || exit /b 1
git add -- index.html server.js package.json backrooms munbub_backrooms_entry_20261106.js tests/backrooms-integration.test.mjs || exit /b 1
git diff --cached --check || exit /b 1
git commit -m "Add taste account-linked Backrooms cooperative 3D mode" || exit /b 1
git push origin HEAD:migration/render-neon || exit /b 1
echo GitHub push complete. Check the Render auto-deployment.
pause
