#!/bin/sh
set -eu
HERE=$(CDPATH='' cd -- "$(dirname -- "$0")" && pwd)
TARGET="$HERE/../../MUNBUB_latest_backrooms_deploy"
command -v git >/dev/null || { echo 'Git is required'; exit 1; }
command -v python3 >/dev/null || { echo 'Python 3 is required'; exit 1; }
command -v npm >/dev/null || { echo 'Node.js/npm are required'; exit 1; }
if [ -e "$TARGET" ]; then echo "Target already exists: $TARGET (refusing overwrite)";exit 1;fi
git clone --depth 1 --branch migration/render-neon https://github.com/SeoJunwhynat/MUNBUB.git "$TARGET"
python3 "$HERE/apply_to_latest.py" "$TARGET"
cd "$TARGET"
npm ci --ignore-scripts --no-audit --no-fund
npm run check
npm test
git add -- index.html server.js package.json backrooms munbub_backrooms_entry_20261106.js tests/backrooms-integration.test.mjs
git diff --cached --check
if git diff --cached --quiet; then echo 'No changes to commit';else
 git commit -m 'Add taste account-linked Backrooms cooperative 3D mode'
 git push origin HEAD:migration/render-neon
fi
echo 'GitHub push successful; check Render service auto-deploy status.'
