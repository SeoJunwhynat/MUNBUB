#!/usr/bin/env python3
"""Safely overlays the Backrooms v3 integration onto an unmodified latest GitHub checkout.
Preserves all existing accounts/achievements/rankings/rooms and avoids overwriting their code.
"""
from pathlib import Path
from shutil import copy2,copytree
import json,re,sys
if len(sys.argv)!=2:
 raise SystemExit('Usage: python apply_to_latest.py /path/to/MUNBUB-checkout')
root=Path(sys.argv[1]).resolve()
pkgfile=root/'package.json';entry=root/'index.html';serverfile=root/'server.js'
assert pkgfile.exists() and entry.exists() and serverfile.exists(),'Root must be the existing taste game repository.'
overlay=Path(__file__).resolve().parent
original=serverfile.read_text('utf8')
assert 'createAppServer' in original or 'const server=createServer' in original,'Unsupported Render Node adapter; aborting safely.'
assert 'backroomsRelay' not in original,'Backrooms integration already present; aborting to avoid duplicate routes.'
assert 'munbub_backrooms_entry_20261106.js' not in entry.read_text('utf8'),'Launcher already exists.'
# Match both the current production adapter (createAppServer) and the earlier build.
import_line="import { fileURLToPath } from 'node:url';"
assert original.count(import_line)==1
imports="import backroomsRelay from './backrooms/server.js';\nimport { session, sameOrigin } from './lib/mb-server.js';"
server=original.replace(import_line,import_line+'\n'+imports,1)
if 'export function createAppServer()' in server:
 # Production's publicFile allowlist already keeps all private Backrooms files inaccessible.
 anchor='      const match = /^\\/api\\/([a-z-]+)\\/?$/.exec(pathname);'
 assert server.count(anchor)==1,'Current adapter API routing changed; abort instead of guessing.'
 indent='      '
else:
 anchor="  if(pathname.startsWith('/api/')){"
 assert server.count(anchor)==1,'Legacy adapter API routing changed; abort instead of guessing.'
 indent='  '
newroutes=f"""{indent}// Backrooms uses the same account cookie but a distinct in-process Node relay.
{indent}if(pathname==='/backrooms'||pathname==='/backrooms/'){{
{indent}  if(!['GET','HEAD'].includes(req.method))return json(res,405,{{error:'GET only'}});
{indent}  const file=fileURLToPath(new URL('./backrooms/index.html',import.meta.url));
{indent}  const info=await stat(file);
{indent}  res.writeHead(200,{{'Content-Type':'text/html; charset=utf-8','Content-Length':info.size,'Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Referrer-Policy':'same-origin'}});
{indent}  if(req.method==='HEAD')return res.end();
{indent}  return createReadStream(file).pipe(res);
{indent}}}
{indent}if(pathname.startsWith('/backrooms/api/')){{
{indent}  if(!['GET','POST'].includes(req.method))return json(res,405,{{error:'지원하지 않는 방식이야.'}});
{indent}  if(req.method==='POST'&&!sameOrigin(req))return json(res,403,{{error:'잘못된 요청 출처야.'}});
{indent}  const identity=session(req);
{indent}  if(!identity)return json(res,401,{{ok:false,error:'맛춘범에 로그인해야 협동 모드를 사용할 수 있어.'}});
{indent}  req._mbBackroomsUser={{id:identity.id,name:identity.name}};
{indent}  req.url=req.url.replace(/^\\/backrooms(?=\\/api\\/)/,'');
{indent}  backroomsRelay.server.emit('request',req,res);
{indent}  return;
{indent}}}
"""
server=server.replace(anchor,newroutes+anchor,1)
# Legacy adapter served any .js; deny Backrooms code and bank direct URLs.
if 'export function createAppServer()' not in server:
 target="  if(req.method!=='GET'&&req.method!=='HEAD')return json(res,405,{error:'GET only'});"
 ix=server.rfind(target)
 assert ix>=0
 server=server[:ix]+"  if(pathname.startsWith('/backrooms/'))return json(res,404,{error:'Not found'});\n"+server[ix:]
index=entry.read_text('utf8')
assert '</body></html>' in index
index=index.replace('</body></html>','<script src="./munbub_backrooms_entry_20261106.js" defer></script></body></html>',1)
pkg=json.loads(pkgfile.read_text('utf8'))
assert pkg.get('type')=='module'
pkg.setdefault('scripts',{})['check']=pkg['scripts'].get('check','node --check server.js')+' && node --check backrooms/server.js && node --check munbub_backrooms_entry_20261106.js'
# Preserve every existing dependency and existing test script.
if not pkg['scripts'].get('test'):pkg['scripts']['test']='node --test tests/*.test.mjs'
# Write only after validating all text anchors.
copytree(overlay/'backrooms',root/'backrooms',dirs_exist_ok=False)
copy2(overlay/'munbub_backrooms_entry_20261106.js',root/'munbub_backrooms_entry_20261106.js')
(root/'tests').mkdir(exist_ok=True)
copy2(overlay/'tests/backrooms-integration.test.mjs',root/'tests/backrooms-integration.test.mjs')
serverfile.write_text(server,'utf8');entry.write_text(index,'utf8');pkgfile.write_text(json.dumps(pkg,ensure_ascii=False,indent=2)+'\n','utf8')
print('Applied Backrooms to',root,'without modifying existing accounts, leaderboards, achievements, rankings or duels.')
